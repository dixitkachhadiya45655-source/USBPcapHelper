# USBPcap Helper (Android)

A small native Android guide app for people who have the USBPcap 1.5.4.0 Windows installer.

## Important limitation
USBPcap 1.5.4.0 is a Windows driver/utility installer. Android cannot install or run its Windows driver. This app provides a checklist and links to the project's official GitHub release; it does not install USBPcap on the phone.

## Open and build
1. Install Android Studio (current stable) and the Android SDK.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s), or run on an Android device/emulator.

The project uses Kotlin, Jetpack Compose, and Material 3. Gradle plugin versions are pinned in the project files; Android Studio may recommend a compatible Gradle/JDK setup.

## Official source
https://github.com/desowin/usbpcap/releases/tag/1.5.4.0

The app opens the official release page or the direct installer URL. Verify downloaded files and only run the installer on a compatible Windows PC if you trust the source.


## Build an APK using only a phone (GitHub Actions)
This project includes `.github/workflows/android-apk.yml` to build a debug APK in GitHub's hosted runner.
1. Create a GitHub repository in your browser.
2. Upload the contents of this project ZIP to the repository root, preserving folders (especially `.github/workflows/`).
3. Open the repository's Actions tab, select "Build Android APK", and tap "Run workflow". If it is not listed, first push/upload the files to the `main` branch and refresh.
4. When the run finishes successfully, open the run, scroll to Artifacts, and download `USBPcapHelper-debug-apk`.
5. Extract the downloaded artifact ZIP, tap `app-debug.apk`, and approve Android's install prompt if you trust the APK you built.
GitHub's interface may vary on mobile; enabling your browser's Desktop site can help.
