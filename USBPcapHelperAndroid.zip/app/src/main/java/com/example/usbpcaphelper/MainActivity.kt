package com.example.usbpcaphelper

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LaptopWindows
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val RELEASE_URL = "https://github.com/desowin/usbpcap/releases/tag/1.5.4.0"
private const val INSTALLER_URL = "https://github.com/desowin/usbpcap/releases/download/1.5.4.0/USBPcapSetup-1.5.4.0.exe"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { USBPcapHelperApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun USBPcapHelperApp() {
    val context = LocalContext.current
    var checked by remember { mutableStateOf(listOf(false, false, false, false)) }
    val steps = listOf(
        "Move to a Windows PC",
        "Download USBPcapSetup-1.5.4.0.exe from the official release",
        "Run the installer and approve the Windows administrator prompt if you trust the source",
        "Follow the setup wizard; restart Windows if the installer asks"
    )
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF2457C5),
            secondary = Color(0xFF5476B8),
            background = Color(0xFFF5F7FB),
            surface = Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("USBPcap Helper", fontWeight = FontWeight.Bold)
                            Text("Installation guide • version 1.0", fontSize = 12.sp)
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF0FF))) {
                    Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.LaptopWindows, contentDescription = null, tint = Color(0xFF2457C5), modifier = Modifier.size(34.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("USBPcap runs on Windows", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("The file you supplied is a Windows installer, not an Android app. Android cannot install its Windows driver. Use this app as a guide, then complete installation on a compatible Windows PC.")
                        }
                    }
                }

                Text("Install checklist", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Tick each item as you complete it.")
                steps.forEachIndexed { index, step ->
                    Card {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked[index],
                                onCheckedChange = { value ->
                                    checked = checked.toMutableList().also { it[index] = value }
                                }
                            )
                            Text(step, modifier = Modifier.weight(1f).padding(vertical = 8.dp))
                        }
                    }
                }

                Button(
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(INSTALLER_URL)))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Get Windows installer")
                }
                OutlinedButton(
                    onClick = {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(RELEASE_URL)))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Info, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("View official release notes")
                }

                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Compatibility note", fontWeight = FontWeight.Bold)
                        Text("The 1.5.4.0 release notes list Windows 7, 8 and 10 (32-bit and 64-bit). Windows 7 may require update KB3033929 or KB4474419. Check the official release notes for details and use a currently supported Windows version where possible.")
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4DF))) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF805500))
                        Text("Security: only run installers from a source you trust. This helper does not install drivers, execute the EXE, or verify the installer on your phone.")
                    }
                }
                Text(
                    "Source: USBPcap project release page on GitHub.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
        }
    }
}
